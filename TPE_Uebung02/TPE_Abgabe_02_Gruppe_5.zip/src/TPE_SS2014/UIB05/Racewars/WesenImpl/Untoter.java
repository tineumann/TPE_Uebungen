package TPE_SS2014.UIB05.Racewars.WesenImpl;

import TPE_SS2014.UIB05.Racewars.WesenAPI.Rasse;

/**
 * Erzeugt ein Wesen der Rasse Untoter.
 * 
 * @author Timo Neumann, 1312143
 * @author Constantin Schneider, 1315272
 * 
 */
public class Untoter extends WesenImpl{

	public Untoter(){
		super(Rasse.UNTOTER);
	}
}
