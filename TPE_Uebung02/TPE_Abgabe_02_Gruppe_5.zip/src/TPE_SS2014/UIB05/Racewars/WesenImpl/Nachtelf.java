package TPE_SS2014.UIB05.Racewars.WesenImpl;

import TPE_SS2014.UIB05.Racewars.WesenAPI.Rasse;

/**
 * Klasse Nachtelf. Erzeugt ein Wesen der Rasse Nachtelf
 * 
 * @author Timo Neumann, 1312143
 * @author Constantin Schneider, 1315272
 * 
 */
public class Nachtelf extends WesenImpl {

	public Nachtelf(){
		super(Rasse.NACHTELF);
	}
}
